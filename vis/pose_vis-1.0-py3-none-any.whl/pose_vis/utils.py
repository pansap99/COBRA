from plyfile import PlyData
import numpy as np

def load_model(model_path):
    """Loads a 3D model provided with a ply format.

    Args:
        model_path (str): Path to 3D model

    Returns:
        tuple: (Model verices, face indices) 
    """
    modeldata = PlyData.read(model_path)
    
    vertices = np.array(modeldata['vertex'][:])
    vertices = vertices.view((vertices.dtype[0], len(vertices.dtype.names)))
    face_ind = map(lambda o: np.array(o) ,np.array(modeldata['face'].data['vertex_indices'])) 
    
    return vertices.astype(np.float32).flatten(),np.array(list(face_ind)).flatten()