import os
import glfw
from OpenGL.GLU import *
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.arrays import vbo
from OpenGL.arrays import *
from OpenGL.GL import shaders


class Shader():
    
    def __init__(self,vertexfilename,fragmentfilename,geometry_filename=None) -> None:
        """Initializes a Shader object. Typically the shader pipeline
        consists of 3 consecutive shaders that are isolated from each other
        and the only communication between them is made using the inputs and outputs.

        Args:
            vertexfilename (str): Path to vertex shader file.
            fragmentfilename (str): Path to fragment shader file.
            geometry_filename (str, optional): Path to geometry shader file. Defaults to None. 
            If None then the pipeline defaults to a pass-through geometry shader. 
        """
        
        self.vertexfilename = vertexfilename
        self.fragmentfilename = fragmentfilename
        self.geometryFilename = geometry_filename
        
    def printID(self):
        print(self.filename)

    def readShadersFromFile(self):
        """
        Serializing the input Shader files.
        """
        with open(self.vertexfilename,'r') as file:
            shader = file.read()
            self.vertexstring = shader
        with open(self.fragmentfilename,'r') as file:
            shader = file.read()
            self.fragmentstring = shader
        if self.geometryFilename is not None:
            with open(self.geometryFilename,'r') as file:
                shader = file.read()
                self.geometrystring = shader
        
    def compileShader(self):
        """Compiles each Shader code and reports any error in compilation.

        Returns:
            vertex: GLuint compiled vertex shader.
            fragment: GLuint compiled fragment shader.
            geometry: GLuint compiled geometry shader. 
            None is return for pass-through geometry shader.
        """
        vertex = shaders.compileShader(self.vertexstring,GL_VERTEX_SHADER)
        fragment = shaders.compileShader(self.fragmentstring,GL_FRAGMENT_SHADER)
        if self.geometryFilename is not None:
            geometry = shaders.compileShader(self.geometrystring,GL_GEOMETRY_SHADER)
            return vertex,fragment,geometry
        else:
            return vertex,fragment,None

    def compileProgram(self,vertex_shader,fragment_shader,geometry_shader):
        """Compiles the whole shader program and returns the program's ID

        Args:
            vertex_shader (int): Compiled vertex shader ID.
            fragment_shader (int): Compiled fragment shader ID.
            geometry_shader (int): Compiled geometry shader ID.

        Returns:
            program (int): Compiled program id.
        """
        if self.geometryFilename is not None:
            program = shaders.compileProgram(vertex_shader,fragment_shader,geometry_shader)
        else:
            program = shaders.compileProgram(vertex_shader,fragment_shader)
        
        return program

    def UseProgram(self,programmID):
        """Use the specific compiled shader program.

        Args:
            programmID (int): Compiled program ID.
        """
        shaders.glUseProgram(programmID)

    


    
    
