import numpy as np




class PerspectiveCamera:
   def __init__(self,width,height) -> None:
       self.FBO_WIDTH = width
       self.FBO_HEIGHT = height
   def fromIntrinsics(self,fx,fy,cx,cy,nearP,farP):
       
       projection = [ 2 * fx / float(self.FBO_WIDTH),     -2 * 0 / float(self.FBO_WIDTH) ,     0,    0,
            0,                       2 * fy / float(self.FBO_HEIGHT),      0,   0,
            1 - 2 * (cx / float(self.FBO_WIDTH)),      2 * (cy / float(self.FBO_HEIGHT)) - 1,   -(farP + nearP) / (farP - nearP),       -1,
            0,                       0,                      2 * farP * nearP / (nearP - farP),       0
            ]
       return np.array(projection).reshape(4,4)